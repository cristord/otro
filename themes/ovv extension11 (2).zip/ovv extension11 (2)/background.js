//chrome.browserAction.onClicked.addListener(function(activeTab){
  //var newURL = "http://envivo.aquilesazar.org/";
  //chrome.tabs.create({ url: newURL });
//});
